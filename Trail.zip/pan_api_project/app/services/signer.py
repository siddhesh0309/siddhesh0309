from OpenSSL import crypto
import json
import base64

def sign_request(payload):
    with open("key.pem", "r") as f:
        key = crypto.load_privatekey(crypto.FILETYPE_PEM, f.read())
    input_str = json.dumps(payload, separators=(',', ':')).encode('utf-8')
    signature = crypto.sign(key, input_str, 'sha256')
    return base64.b64encode(signature).decode()
