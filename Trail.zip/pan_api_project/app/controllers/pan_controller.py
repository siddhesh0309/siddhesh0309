from flask import Blueprint, request, jsonify
from app.models.pan_models import PANRequest
from app.services.signer import sign_request
import requests
from datetime import datetime

pan_blueprint = Blueprint('pan', __name__)

@pan_blueprint.route('/verify_pan', methods=['POST'])
def verify_pan():
    data = request.json
    try:
        pan_req = PANRequest(**data)
        transaction_id = f"{pan_req.user_id}:{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        header = {
            "User_ID": pan_req.user_id,
            "Records_count": str(len(pan_req.input_data)),
            "Request_time": datetime.now().isoformat(),
            "Transaction_ID": transaction_id,
            "Version": "4"
        }
        signed_input = sign_request({"inputData": pan_req.input_data})
        body = {
            "inputData": pan_req.input_data,
            "signature": signed_input
        }
        full_payload = {**header, **body}
        response = requests.post(
            "https://121.240.36.237/TIN/PanInquiryAPIBackEnd",
            json=full_payload,
            headers={"Content-Type": "application/json"},
            verify=False
        )
        return jsonify(response.json()), response.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 400
