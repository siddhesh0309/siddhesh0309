from typing import List
from pydantic import BaseModel

class PANData(BaseModel):
    pan: str
    name: str
    fathername: str
    dob: str

class PANRequest(BaseModel):
    user_id: str
    input_data: List[PANData]
