from flask import Flask
from app.controllers.pan_controller import pan_blueprint

def create_app():
    app = Flask(__name__)
    app.register_blueprint(pan_blueprint)
    return app
