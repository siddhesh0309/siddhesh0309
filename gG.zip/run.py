from flask import Flask
from flask_restful import Api
from controllers.panController import PANVerification

def init():
    app = Flask(__name__)
    api = Api(app)
    api.add_resource(PANVerification, "/verify_pan")
    return app

application = init()

if __name__ == "__main__":
    application.run(debug=True)
