from flask_restful import Resource
from flask import request, jsonify
from models.pan_models import PANRequest
from services.signer import sign_request
import requests
import json
from datetime import datetime

class PANVerification(Resource):
    def post(self):
        try:
            data = request.json
            print("Received from Insomnia:", data)

            pan_req = PANRequest(**data)
            input_data_dicts = [record.dict() for record in pan_req.input_data]

            transaction_id = f"{pan_req.user_id}:{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
            request_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

            to_sign = {"inputData": input_data_dicts}
            signature = sign_request(to_sign)

            full_payload = {
                "User_ID": pan_req.user_id,
                "Records_count": str(len(input_data_dicts)),
                "Request_time": request_time,
                "Transaction_ID": transaction_id,
                "Version": "4",
                "inputData": input_data_dicts,
                "signature": signature
            }

            print("---- Payload Sent to Protean ----")
            print(json.dumps(full_payload, indent=2))

            response = requests.post(
                "https://121.240.36.237/TIN/PanInquiryAPIBackEnd",
                json=full_payload,
                headers={"Content-Type": "application/json"},
                verify=False
            )

            return jsonify(response.json()), response.status_code

        except Exception as e:
            return jsonify({"error": str(e)}), 400
