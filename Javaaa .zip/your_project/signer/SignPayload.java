import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.Security;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

import org.bouncycastle.cms.*;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.cms.jcajce.*;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.bouncycastle.util.encoders.Base64;

public class SignPayload {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: java SignPayload <path_to_json_file>");
            System.exit(1);
        }

        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

        String keystorePath = "keystore/your_keystore.jks";
        String keystorePassword = "your_keystore_password";
        String keyAlias = "your_key_alias";
        String keyPassword = "your_key_password";

        byte[] payloadBytes = Files.readAllBytes(Paths.get(args[0]));

        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream(keystorePath), keystorePassword.toCharArray());

        PrivateKey privateKey = (PrivateKey) ks.getKey(keyAlias, keyPassword.toCharArray());
        X509Certificate cert = (X509Certificate) ks.getCertificate(keyAlias);

        CMSTypedData cmsData = new CMSProcessableByteArray(payloadBytes);
        CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
        gen.addSignerInfoGenerator(
                new JcaSignerInfoGeneratorBuilder(new JcaDigestCalculatorProviderBuilder().build())
                        .build(new JcaContentSignerBuilder("SHA256withRSA").build(privateKey), cert));
        gen.addCertificate(new JcaX509CertificateHolder(cert));

        CMSSignedData signedData = gen.generate(cmsData, true);
        byte[] encoded = signedData.getEncoded();
        String base64Signature = new String(Base64.encode(encoded));
        System.out.println(base64Signature);
    }
}
