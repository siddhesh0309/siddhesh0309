from flask import Blueprint, request, jsonify
import tempfile, subprocess, json, requests
from pydantic import ValidationError
from models.pan_model import PANRequest

bp = Blueprint("pan_verification", __name__)

UAT_API_ENDPOINT = "https://121.240.36.237/TIN/PanInquiryAPIBackEnd"
HEADERS = {"Content-Type": "application/json"}

def generate_signature(payload: dict) -> str:
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".json", delete=False) as f:
        json.dump(payload, f)
        f.flush()

        result = subprocess.run([
            "java", "-cp", "signer:libs/*", "SignPayload", f.name
        ], capture_output=True, text=True)

        if result.returncode != 0:
            raise Exception(f"Java signer error: {result.stderr}")
        
        return result.stdout.strip()

@bp.route('/verify_pan', methods=['POST'])
def verify_pan():
    try:
        data = request.get_json()
        try:
            validated_data = PANRequest(**data)
        except ValidationError as ve:
            return jsonify({"validation_error": ve.errors()}), 422

        payload = {
            "header": {
                "User_ID": validated_data.User_ID,
                "Records_count": validated_data.Records_count,
                "Request_time": validated_data.Request_time,
                "Transaction_ID": validated_data.Transaction_ID,
                "Version": validated_data.Version
            },
            "request": {
                "inputData": [entry.dict() for entry in validated_data.inputData]
            }
        }

        signature = generate_signature(payload)
        payload["request"]["signature"] = signature

        response = requests.post(UAT_API_ENDPOINT, json=payload, headers=HEADERS, verify=False)
        return jsonify({"status_code": response.status_code, "response": response.json()})

    except Exception as e:
        return jsonify({"error": str(e)}), 500
