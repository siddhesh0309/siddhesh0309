from flask import Flask
from controller.pan_controller import bp as pan_blueprint

app = Flask(__name__)
app.register_blueprint(pan_blueprint)

if __name__ == '__main__':
    app.run(debug=True)
