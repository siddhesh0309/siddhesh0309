from dataclasses import dataclass
from typing import List

@dataclass
class PANData:
    pan: str
    name: str
    fathername: str
    dob: str  # Format: dd-mm-yyyy

@dataclass
class PANRequest:
    User_ID: str
    Records_count: int
    Request_time: str
    Transaction_ID: str
    Version: str
    inputData: List[PANData]
